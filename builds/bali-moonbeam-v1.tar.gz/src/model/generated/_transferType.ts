export enum TransferType {
  Native = "Native",
  Contribution = "Contribution",
  Xcm = "Xcm",
}
