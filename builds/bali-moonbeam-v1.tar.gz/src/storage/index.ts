import * as parachainStaking from './parachainStaking'

const storage = { parachainStaking }

export default storage
