export enum TransferDirection {
  From = "From",
  To = "To",
}
