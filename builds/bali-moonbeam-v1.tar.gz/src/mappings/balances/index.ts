import * as extrinsics from './calls'

export default {
    extrinsics,
}
