export enum StakingRole {
  Collator = "Collator",
  Nominator = "Nominator",
  Idle = "Idle",
}
