export const EXTRINSIC_SUCCESS = 'system.ExtrinsicSuccess'
export const EXTRINSIC_FAILED = 'system.ExtrinsicFailed'
export const DEFAULT_BATCH_SIZE = 500
export const DEFAULT_PORT = 3000
